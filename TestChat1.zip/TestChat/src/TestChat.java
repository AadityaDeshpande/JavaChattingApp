import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class TestChat {
	//data members
	private String userName;
	
	//getters and setters
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	//member functions
	
	public Connection getCon() {
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	    //final String DB_URL= "jdbc:mysql://192.168.137.159/chatusers";
	    final String DB_URL = "jdbc:mysql://localhost/chatusers";
		final String USER = "root";
	    //final String PASS = "password";
		final String PASS ="";
		Connection conn=null;
		
		 try {
			 Class.forName(JDBC_DRIVER);
			 conn = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return conn;
	}
	
	public void tablewrite(String sendto,String m1) { //db columns
		String msg="";
		
		/*int sturoll=proll;
		int stumark=pmark;*/
		
		  try {
	          Connection conn = getCon();
	          // Execute SQL query
	         String sql = "insert into "+sendto+" (msgfrom,message)values(?,?)"; 
PreparedStatement pst=conn.prepareStatement(sql);
	         pst.setString(1,userName);
	         pst.setString(2, m1);
	         
	         int i= pst.executeUpdate();
	         
	         if(i!=0){
	        	 msg="Message sent successfully";
	             System.out.println(msg); 
	             
	         }
	         else{  
	             msg="Message NOT SENT";
	             System.out.println(msg);
	            }  
	  	          	                   
	           pst.close();
	           conn.close();
	        } catch(SQLException se) {
	           //Handle errors for JDBC
	           se.printStackTrace();
	        } catch(Exception e) {
	           //Handle errors for Class.forName
	           e.printStackTrace();
	        } finally {
	            //finally block used to close resources
	        }	
	}
	
	
	public void tableread(String tbname) {
		String msg="";
		  try {
	          Connection conn = getCon();
	          // Execute SQL query
	          
	          Statement stmt = conn.createStatement();
	          String sql;
	          sql = "SELECT id,msgfrom,message FROM "+tbname;
	          ResultSet rs = stmt.executeQuery(sql);
	          
	          while(rs.next()) {
	        	  int id = rs.getInt("id");
	        	  String use1 = rs.getString("msgfrom");
	        	 String msg1 = rs.getString("message");
	        	 //int stumark=rs.getInt("stumark");
	   System.out.println("id: "+id+" Message from: "+use1+" message is: "+msg1);
	          }
	          
	           conn.close();
	        } catch(SQLException se) {
	           //Handle errors for JDBC
	           se.printStackTrace();
	        } catch(Exception e) {
	           //Handle errors for Class.forName
	           e.printStackTrace();
	        } finally {
	            //finally block used to close resources
	        }
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Scanner sc = new Scanner(System.in);
		TestChat obj = new TestChat();
		Newuser user = new Newuser();
		
		System.out.println("Are you a new user ? (yes/no)");
		String res = sc.nextLine();
		//Anand Module called
		if(res.equals("yes"))
		 user.newus();
		
		System.out.println("Hello, please enter your name, ");
		String myname = sc.nextLine();
		obj.setUserName(myname);
		
		System.out.println("your old messages are");
		
		//obj.tableread(myname);
		// Devashish and saish module called
		ThreadClass cl = new ThreadClass(myname);
		
		System.out.println("\nwho do you want to send message");	
			//show users
		String sendto = sc.nextLine();
		
		
		System.out.println("Enter message you want to send");	
		
		String msg = sc.nextLine();
		
		obj.tablewrite(sendto, msg); 
		//obj.tablewrite(sendto,msg);
		
		//obj.tableread();
		}
		catch(Exception e) {
			System.out.println("link re establishment, run again");
			//Connection c = obj.getCon();
		}
		
	}
}