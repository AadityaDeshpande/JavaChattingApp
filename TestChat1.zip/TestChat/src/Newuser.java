
import java.sql.*;
import java.util.Scanner;
public class Newuser extends TestChat
{

	
	public void newus()
	{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your name: ");
			String name = sc.nextLine();
			System.out.println( name+ "your name is getting inserted ");
			 try
			 {
		          Connection conn = getCon();		          
		          Statement stmt = conn.createStatement();
		          String sql;
		          sql = "insert into users values('"+ name +"')";
				  int i=stmt.executeUpdate(sql);	          
				  System.out.println(i+" records inserted in users"); 
				  String sql1;
				  
				  //sql1 = "CREATE TABLE ? ("
				  
				  sql1="create table " + name + " (id INT(11) AUTO_INCREMENT PRIMARY KEY, msgfrom varchar(10), message varchar(50))";
				  
				  
				  int j=stmt.executeUpdate(sql1);
				  System.out.println(j+" table '"+ name +"' created successfully ");
		          conn.close();
		      } 
			  catch(SQLException se)
			  {
		           //Handle errors for JDBC
		           se.printStackTrace();
		      } 
			  catch(Exception e)
			  {
		           //Handle errors for Class.forName
		           e.printStackTrace();
		      }
		}
}